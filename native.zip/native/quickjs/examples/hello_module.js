/* example of JS module */

import { fib } from "./fib_module.js";

console.log("Hello World");
console.log("fib(10)=", fib(10));
